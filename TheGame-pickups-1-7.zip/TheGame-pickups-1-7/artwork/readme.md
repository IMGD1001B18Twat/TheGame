This is the folder for artwork.
